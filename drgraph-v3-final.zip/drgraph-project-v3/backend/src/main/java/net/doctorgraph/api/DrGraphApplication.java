package net.doctorgraph.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DrGraphApplication {
    public static void main(String[] args) {
        SpringApplication.run(DrGraphApplication.class, args);
    }
}
